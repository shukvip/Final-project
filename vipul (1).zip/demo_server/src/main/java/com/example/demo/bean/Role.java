package com.example.demo.bean;

public enum Role {
	Customer,Admin,Merchant
}
