package com.example.demo.repo;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.bean.Admin;
import com.example.demo.bean.Customer;
import com.example.demo.bean.Merchant;
import com.example.demo.bean.User;



@Repository
@Transactional
public class UserDAOImpl implements userDAO {

	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public void createCustomer(Customer user) {
		
		entitymanager.persist(user);
		
	
	}


	@Override
	public void createMerchant(Merchant mer) {
		// TODO Auto-generated method stub
		entitymanager.persist(mer);
		
		
	}



	
	@Override
	public void createUser(User user) {
		// TODO Auto-generated method stub
		entitymanager.persist(user);
		
	}


	@Override
	public boolean validateUser(User user) {
		// TODO Auto-generated method stub
		
		String email=user.getEmailId();
		String password=user.getPassword();
		
		boolean flag=false;
		Query query=entitymanager.createQuery("Select u from User u where emailId=:email");
		query.setParameter("email", email);
	
		User u=(User) query.getSingleResult();
		System.out.println("after single result");
			if(u.getPassword().equals(password))
				{
				flag=true;
				System.out.println("in equal condition");
				}
		
		return flag;
	/*	  User result =ls.get(0);
	//	System.out.println(query.getResultList());
		System.out.println(result.getRole());*/
		
		
	}


	@Override
	public Admin getAdminByEmail(String email) {
		// TODO Auto-generated method stub
			
		Query query=entitymanager.createQuery("Select u from Admin u where email=:email");
		query.setParameter("email", email);
		Admin u=(Admin) query.getSingleResult();
		
		return u;
		
	}
public String forgetEmail(String emailid) {
	Query query=entitymanager.createQuery("Select u from User u where emailid=:emailid");
	query.setParameter("emailid", emailid);
		
				User user=(User) query.getSingleResult();
				return user.getPassword();
}

	@Override
	public Merchant getMerchantByEmail(String email) {
		// TODO Auto-generated method stub
		
		Query query=entitymanager.createQuery("Select u from Merchant u where email=:email");
		query.setParameter("email", email);
		Merchant u=(Merchant) query.getSingleResult();
		return u;
	}


	@Override
	public Customer getCustomerByEmail(String email) {
		// TODO Auto-generated method stub
		Query query=entitymanager.createQuery("Select u from Customer u where email=:email");
		query.setParameter("email", email);
		Customer u=(Customer) query.getSingleResult();
		return u;
	}


	@Override
	public void changePassword(User user) {
		// TODO Auto-generated method stub
		String email = user.getEmailId();
		String pass = user.getPassword();
		Query query=entitymanager.createQuery("Select u from Customer u where password=:pass");
		query.setParameter("password", pass);
		 query.getSingleResult();
		
		
		
	}




}
