package com.example.democlient.boot.beans;

public enum SoftDelete {
	Activated, Deactivated
}
