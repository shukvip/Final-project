package com.example.democlient.boot.beans;

public enum Role {
	Customer,Admin,Merchant
}
