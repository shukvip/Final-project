package com.example.democlient.boot.beans;

public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics,Sports
}
